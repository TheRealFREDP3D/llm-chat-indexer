"""
Test package for LLM Chat Indexer.
"""
